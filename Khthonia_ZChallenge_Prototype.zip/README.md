Refer to the online GitHub repository for the full formatted README.
